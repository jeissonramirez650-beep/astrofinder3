# Server-side receipt verification notes

## Google Play
- Create a Google Cloud service account and enable the Google Play Android Developer API.
- Use google-api-python-client and google-auth to call purchases.products.get or purchases.subscriptions.get.
- Verify purchaseState and consumptionState fields.

## Apple App Store
- Use the verifyReceipt endpoints (sandbox for testing).
- For subscriptions, include the shared secret in the payload.
- Validate status codes and latest_receipt_info.

Place verification logic on your backend and secure endpoints. Do not trust client-side receipts alone.