f
r
o
m
 
f
l
a
s
k
 
i
m
p
o
r
t
 
F
l
a
s
k
,
 
r
e
q
u
e
s
t
,
 
j
s
o
n
i
f
y


f
r
o
m
 
s
g
p
4
.
a
p
i
 
i
m
p
o
r
t
 
S
a
t
r
e
c
,
 
W
G
S
7
2


f
r
o
m
 
s
g
p
4
.
a
p
i
 
i
m
p
o
r
t
 
j
d
a
y


i
m
p
o
r
t
 
m
a
t
h


i
m
p
o
r
t
 
n
u
m
p
y
 
a
s
 
n
p


f
r
o
m
 
d
a
t
e
t
i
m
e
 
i
m
p
o
r
t
 
d
a
t
e
t
i
m
e
,
 
t
i
m
e
z
o
n
e




a
p
p
 
=
 
F
l
a
s
k
(
_
_
n
a
m
e
_
_
)




d
e
f
 
t
e
m
e
_
t
o
_
e
c
e
f
(
t
e
m
e
_
p
o
s
,
 
g
m
s
t
)
:


 
 
 
 
#
 
t
e
m
e
_
p
o
s
:
 
(
x
,
 
y
,
 
z
)
 
i
n
 
k
m


 
 
 
 
#
 
r
o
t
a
t
e
 
a
r
o
u
n
d
 
Z
 
b
y
 
g
m
s
t
 
(
i
n
 
r
a
d
i
a
n
s
)
 
t
o
 
g
e
t
 
p
s
e
u
d
o
-
E
C
E
F
 
(
a
p
p
r
o
x
)


 
 
 
 
c
o
s
_
g
 
=
 
m
a
t
h
.
c
o
s
(
g
m
s
t
)


 
 
 
 
s
i
n
_
g
 
=
 
m
a
t
h
.
s
i
n
(
g
m
s
t
)


 
 
 
 
x
 
=
 
 
c
o
s
_
g
 
*
 
t
e
m
e
_
p
o
s
[
0
]
 
+
 
s
i
n
_
g
 
*
 
t
e
m
e
_
p
o
s
[
1
]


 
 
 
 
y
 
=
 
-
s
i
n
_
g
 
*
 
t
e
m
e
_
p
o
s
[
0
]
 
+
 
c
o
s
_
g
 
*
 
t
e
m
e
_
p
o
s
[
1
]


 
 
 
 
z
 
=
 
 
t
e
m
e
_
p
o
s
[
2
]


 
 
 
 
r
e
t
u
r
n
 
n
p
.
a
r
r
a
y
(
[
x
,
 
y
,
 
z
]
)




d
e
f
 
g
s
t
i
m
e
_
f
r
o
m
_
d
a
t
e
t
i
m
e
(
d
t
)
:


 
 
 
 
#
 
c
o
m
p
u
t
e
 
G
M
S
T
 
i
n
 
r
a
d
i
a
n
s
 
u
s
i
n
g
 
a
 
s
t
a
n
d
a
r
d
 
a
p
p
r
o
x
i
m
a
t
i
o
n


 
 
 
 
#
 
d
t
 
m
u
s
t
 
b
e
 
t
i
m
e
z
o
n
e
-
a
w
a
r
e
 
U
T
C


 
 
 
 
y
e
a
r
 
=
 
d
t
.
y
e
a
r


 
 
 
 
m
o
n
t
h
 
=
 
d
t
.
m
o
n
t
h


 
 
 
 
d
a
y
 
=
 
d
t
.
d
a
y


 
 
 
 
h
o
u
r
 
=
 
d
t
.
h
o
u
r


 
 
 
 
m
i
n
u
t
e
 
=
 
d
t
.
m
i
n
u
t
e


 
 
 
 
s
e
c
o
n
d
 
=
 
d
t
.
s
e
c
o
n
d
 
+
 
d
t
.
m
i
c
r
o
s
e
c
o
n
d
*
1
e
-
6


 
 
 
 
j
d
,
 
f
r
 
=
 
j
d
a
y
(
y
e
a
r
,
 
m
o
n
t
h
,
 
d
a
y
,
 
h
o
u
r
,
 
m
i
n
u
t
e
,
 
s
e
c
o
n
d
)


 
 
 
 
T
 
=
 
(
j
d
 
-
 
2
4
5
1
5
4
5
.
0
)
/
3
6
5
2
5
.
0


 
 
 
 
#
 
i
n
 
d
e
g
r
e
e
s


 
 
 
 
g
m
s
t
_
d
e
g
 
=
 
2
8
0
.
4
6
0
6
1
8
3
7
 
+
 
3
6
0
.
9
8
5
6
4
7
3
6
6
2
9
*
(
j
d
 
-
 
2
4
5
1
5
4
5
.
0
)
 
+
 
0
.
0
0
0
3
8
7
9
3
3
*
T
*
T
 
-
 
(
T
*
T
*
T
)
/
3
8
7
1
0
0
0
0
.
0


 
 
 
 
g
m
s
t
_
d
e
g
 
=
 
g
m
s
t
_
d
e
g
 
%
 
3
6
0
.
0


 
 
 
 
g
m
s
t
 
=
 
m
a
t
h
.
r
a
d
i
a
n
s
(
g
m
s
t
_
d
e
g
)


 
 
 
 
r
e
t
u
r
n
 
g
m
s
t




d
e
f
 
e
c
e
f
_
t
o
_
e
n
u
(
e
c
i
_
e
c
e
f
,
 
l
a
t
_
d
e
g
,
 
l
o
n
_
d
e
g
)
:


 
 
 
 
#
 
C
o
n
v
e
r
t
 
E
C
E
F
 
v
e
c
t
o
r
 
t
o
 
t
o
p
o
c
e
n
t
r
i
c
 
E
N
U
 
c
o
o
r
d
i
n
a
t
e
s
 
a
t
 
o
b
s
e
r
v
e
r
 
l
a
t
/
l
o
n
 
(
d
e
g
r
e
e
s
)


 
 
 
 
l
a
t
 
=
 
m
a
t
h
.
r
a
d
i
a
n
s
(
l
a
t
_
d
e
g
)


 
 
 
 
l
o
n
 
=
 
m
a
t
h
.
r
a
d
i
a
n
s
(
l
o
n
_
d
e
g
)


 
 
 
 
#
 
r
o
t
a
t
i
o
n
 
m
a
t
r
i
x


 
 
 
 
s
i
n
_
l
a
t
 
=
 
m
a
t
h
.
s
i
n
(
l
a
t
)


 
 
 
 
c
o
s
_
l
a
t
 
=
 
m
a
t
h
.
c
o
s
(
l
a
t
)


 
 
 
 
s
i
n
_
l
o
n
 
=
 
m
a
t
h
.
s
i
n
(
l
o
n
)


 
 
 
 
c
o
s
_
l
o
n
 
=
 
m
a
t
h
.
c
o
s
(
l
o
n
)


 
 
 
 
R
 
=
 
n
p
.
a
r
r
a
y
(
[


 
 
 
 
 
 
 
 
[
-
s
i
n
_
l
o
n
,
 
 
 
 
 
 
 
 
 
 
 
c
o
s
_
l
o
n
,
 
 
 
 
 
 
 
 
 
 
 
 
0
]
,


 
 
 
 
 
 
 
 
[
-
s
i
n
_
l
a
t
*
c
o
s
_
l
o
n
,
 
 
-
s
i
n
_
l
a
t
*
s
i
n
_
l
o
n
,
 
 
 
 
c
o
s
_
l
a
t
]
,


 
 
 
 
 
 
 
 
[
 
c
o
s
_
l
a
t
*
c
o
s
_
l
o
n
,
 
 
 
c
o
s
_
l
a
t
*
s
i
n
_
l
o
n
,
 
 
 
 
s
i
n
_
l
a
t
]


 
 
 
 
]
)


 
 
 
 
e
n
u
 
=
 
R
.
d
o
t
(
e
c
i
_
e
c
e
f
)


 
 
 
 
r
e
t
u
r
n
 
e
n
u




d
e
f
 
e
n
u
_
t
o
_
a
z
_
e
l
(
e
n
u
)
:


 
 
 
 
e
 
=
 
e
n
u
[
0
]
;
 
n
 
=
 
e
n
u
[
1
]
;
 
u
 
=
 
e
n
u
[
2
]


 
 
 
 
h
o
r
i
z
_
d
i
s
t
 
=
 
m
a
t
h
.
s
q
r
t
(
e
*
e
 
+
 
n
*
n
)


 
 
 
 
a
z
 
=
 
m
a
t
h
.
d
e
g
r
e
e
s
(
m
a
t
h
.
a
t
a
n
2
(
e
,
 
n
)
)
 
%
 
3
6
0
.
0


 
 
 
 
e
l
 
=
 
m
a
t
h
.
d
e
g
r
e
e
s
(
m
a
t
h
.
a
t
a
n
2
(
u
,
 
h
o
r
i
z
_
d
i
s
t
)
)


 
 
 
 
r
n
g
 
=
 
m
a
t
h
.
s
q
r
t
(
e
*
e
 
+
 
n
*
n
 
+
 
u
*
u
)


 
 
 
 
r
e
t
u
r
n
 
a
z
,
 
e
l
,
 
r
n
g




@
a
p
p
.
r
o
u
t
e
(
'
/
p
r
o
p
a
g
a
t
e
'
,
 
m
e
t
h
o
d
s
=
[
'
P
O
S
T
'
]
)


d
e
f
 
p
r
o
p
a
g
a
t
e
(
)
:


 
 
 
 
d
a
t
a
 
=
 
r
e
q
u
e
s
t
.
g
e
t
_
j
s
o
n
(
)


 
 
 
 
t
l
e
1
 
=
 
d
a
t
a
.
g
e
t
(
'
t
l
e
1
'
)


 
 
 
 
t
l
e
2
 
=
 
d
a
t
a
.
g
e
t
(
'
t
l
e
2
'
)


 
 
 
 
u
t
c
_
i
s
o
 
=
 
d
a
t
a
.
g
e
t
(
'
u
t
c
_
i
s
o
'
)


 
 
 
 
l
a
t
 
=
 
f
l
o
a
t
(
d
a
t
a
.
g
e
t
(
'
l
a
t
'
)
)


 
 
 
 
l
o
n
 
=
 
f
l
o
a
t
(
d
a
t
a
.
g
e
t
(
'
l
o
n
'
)
)


 
 
 
 
i
f
 
n
o
t
 
(
t
l
e
1
 
a
n
d
 
t
l
e
2
 
a
n
d
 
u
t
c
_
i
s
o
)
:


 
 
 
 
 
 
 
 
r
e
t
u
r
n
 
j
s
o
n
i
f
y
(
{
'
e
r
r
o
r
'
:
'
m
i
s
s
i
n
g
 
p
a
r
a
m
e
t
e
r
s
'
}
)
,
 
4
0
0


 
 
 
 
t
r
y
:


 
 
 
 
 
 
 
 
d
t
 
=
 
d
a
t
e
t
i
m
e
.
f
r
o
m
i
s
o
f
o
r
m
a
t
(
u
t
c
_
i
s
o
.
r
e
p
l
a
c
e
(
'
Z
'
,
'
+
0
0
:
0
0
'
)
)


 
 
 
 
e
x
c
e
p
t
 
E
x
c
e
p
t
i
o
n
 
a
s
 
e
:


 
 
 
 
 
 
 
 
r
e
t
u
r
n
 
j
s
o
n
i
f
y
(
{
'
e
r
r
o
r
'
:
'
i
n
v
a
l
i
d
 
u
t
c
_
i
s
o
 
f
o
r
m
a
t
 
(
u
s
e
 
I
S
O
 
8
6
0
1
)
'
}
)
,
 
4
0
0




 
 
 
 
s
a
t
 
=
 
S
a
t
r
e
c
.
t
w
o
l
i
n
e
2
r
v
(
t
l
e
1
,
 
t
l
e
2
)


 
 
 
 
j
d
,
 
f
r
 
=
 
j
d
a
y
(
d
t
.
y
e
a
r
,
 
d
t
.
m
o
n
t
h
,
 
d
t
.
d
a
y
,
 
d
t
.
h
o
u
r
,
 
d
t
.
m
i
n
u
t
e
,
 
d
t
.
s
e
c
o
n
d
 
+
 
d
t
.
m
i
c
r
o
s
e
c
o
n
d
/
1
e
6
)


 
 
 
 
e
,
 
r
,
 
v
 
=
 
s
a
t
.
s
g
p
4
(
j
d
,
 
f
r
)


 
 
 
 
i
f
 
e
 
!
=
 
0
:


 
 
 
 
 
 
 
 
r
e
t
u
r
n
 
j
s
o
n
i
f
y
(
{
'
e
r
r
o
r
'
:
'
s
g
p
4
 
p
r
o
p
a
g
a
t
i
o
n
 
e
r
r
o
r
'
,
 
'
c
o
d
e
'
:
 
e
}
)
,
 
5
0
0




 
 
 
 
t
e
m
e
_
p
o
s
 
=
 
r


 
 
 
 
g
m
s
t
 
=
 
g
s
t
i
m
e
_
f
r
o
m
_
d
a
t
e
t
i
m
e
(
d
t
)


 
 
 
 
e
c
e
f
 
=
 
t
e
m
e
_
t
o
_
e
c
e
f
(
t
e
m
e
_
p
o
s
,
 
g
m
s
t
)


 
 
 
 
R
_
e
a
r
t
h
 
=
 
6
3
7
8
.
1
3
7


 
 
 
 
l
a
t
_
r
 
=
 
m
a
t
h
.
r
a
d
i
a
n
s
(
l
a
t
)


 
 
 
 
l
o
n
_
r
 
=
 
m
a
t
h
.
r
a
d
i
a
n
s
(
l
o
n
)


 
 
 
 
o
b
s
_
x
 
=
 
R
_
e
a
r
t
h
 
*
 
m
a
t
h
.
c
o
s
(
l
a
t
_
r
)
 
*
 
m
a
t
h
.
c
o
s
(
l
o
n
_
r
)


 
 
 
 
o
b
s
_
y
 
=
 
R
_
e
a
r
t
h
 
*
 
m
a
t
h
.
c
o
s
(
l
a
t
_
r
)
 
*
 
m
a
t
h
.
s
i
n
(
l
o
n
_
r
)


 
 
 
 
o
b
s
_
z
 
=
 
R
_
e
a
r
t
h
 
*
 
m
a
t
h
.
s
i
n
(
l
a
t
_
r
)


 
 
 
 
r
h
o
 
=
 
e
c
e
f
 
-
 
n
p
.
a
r
r
a
y
(
[
o
b
s
_
x
,
 
o
b
s
_
y
,
 
o
b
s
_
z
]
)


 
 
 
 
e
n
u
 
=
 
e
c
e
f
_
t
o
_
e
n
u
(
r
h
o
,
 
l
a
t
,
 
l
o
n
)


 
 
 
 
a
z
,
 
e
l
,
 
r
n
g
 
=
 
e
n
u
_
t
o
_
a
z
_
e
l
(
e
n
u
)


 
 
 
 
r
e
t
u
r
n
 
j
s
o
n
i
f
y
(
{
'
a
z
'
:
 
a
z
,
 
'
a
l
t
'
:
 
e
l
,
 
'
r
a
n
g
e
_
k
m
'
:
 
r
n
g
}
)




i
f
 
_
_
n
a
m
e
_
_
 
=
=
 
'
_
_
m
a
i
n
_
_
'
:


 
 
 
 
a
p
p
.
r
u
n
(
h
o
s
t
=
'
0
.
0
.
0
.
0
'
,
 
p
o
r
t
=
5
0
0
0
,
 
d
e
b
u
g
=
T
r
u
e
)