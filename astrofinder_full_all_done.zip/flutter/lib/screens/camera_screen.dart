import 'dart:async';
import 'dart:convert';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:camera/camera.dart';
import 'package:flutter_compass/flutter_compass.dart';
import '../services/sensor_fusion.dart';
import 'package:sensors_plus/sensors_plus.dart';
import '../widgets/overlay_painter.dart';
import '../services/astro_engine.dart';
import '../services/tle_service.dart';
import '../services/sgp4_stub.dart';
import '../data/stars_extended.json' as stars_json;
import 'iap_screen.dart';
import 'package:http/http.dart' as http;

class CameraScreen extends StatefulWidget {
  @override
  _CameraScreenState createState() => _CameraScreenState();
}

class _CameraScreenState extends State<CameraScreen> with WidgetsBindingObserver {
  CameraController? controller;
  List<CameraDescription> cameras = [];
  double heading = 0.0; // device compass heading (degrees)
  double pitch = 0.0; // device pitch approximation (degrees)
  StreamSubscription? _compassSub;
  StreamSubscription? _accelSub;
  final SensorFusion fusion = SensorFusion();

  List<dynamic> stars = [];
  List<ProjectedObject> projected = [];
  bool showPlanets = true, showConstellations = true, showSatellites = true, showEvents = true;
  final tleService = TleService();
  final backendUrl = 'http://10.0.2.2:5000/propagate'; // emulator localhost default; change when backend deployed

  @override
  void initState() {
    super.initState();
    _initCameras();
    _loadStars();
    _startSensors();
    fusion.start();
  }

  Future<void> _initCameras() async {
    cameras = await availableCameras();
    if (cameras.isNotEmpty) {
      controller = CameraController(cameras[0], ResolutionPreset.medium, enableAudio: false);
      await controller!.initialize();
      setState(() {});
      // start projection loop
      _projectionLoop();
    }
  }

  void _startSensors() {
    _compassSub = FlutterCompass.events?.listen((event) {
      if (event != null && event.heading != null) {
        setState(() { heading = event.heading!; });
      }
    });
    _accelSub = accelerometerEvents.listen((ev) {
      // approximate pitch from accelerometer z value
      // pitch = atan2(-ax, sqrt(ay^2 + az^2)) in degrees - simplified
      double ax = ev.x, ay = ev.y, az = ev.z;
      double p = math.atan2(-ax, math.sqrt(ay*ay + az*az)) * 180.0 / math.pi;
      setState(() { pitch = p; });
    });
  }

  Future<void> _loadStars() async {
    // load JSON from asset (in this simplified project we read file synchronously)
    final s = await DefaultAssetBundle.of(context).loadString('lib/data/stars_extended.json');
    final parsed = json.decode(s) as List<dynamic>;
    setState(() { stars = parsed; });
  }

  Timer? _projTimer;
  void _projectionLoop() {
    _projTimer?.cancel();
    _projTimer = Timer.periodic(Duration(milliseconds: 500), (_) => _projectObjects());
  }

  Future<void> _projectObjects() async {
    if (controller == null || !controller!.value.isInitialized) return;
    final size = controller!.value.previewSize;
    if (size == null) return;
    final screenW = MediaQuery.of(context).size.width;
    final screenH = MediaQuery.of(context).size.height;
    final fovHorizontal = 60.0; // approximate camera FOV degrees
    final fovVertical = fovHorizontal * (screenH / screenW);

    List<ProjectedObject> list = [];

    final utc = DateTime.now().toUtc();
    // get user location? For this simplified version we assume lat/lon are set to 0,0 or you can get from geolocator
    double lat = 4.6, lon = -74.1; // replace with actual geolocator data for accuracy

    // Stars and planets
    for (var s in stars) {
      try {
        final ra = (s['ra_hours'] as num).toDouble();
        final dec = (s['dec_deg'] as num).toDouble();
        final t = AstroEngine.raDecToAzAlt(ra, dec, utc, lat, lon);
        double az = t['az']!;
        double alt = t['alt']!;
        // visibility filter: only above horizon
        if (alt > 0) {
          // compute relative az difference between device heading and object az
          double relativeAz = normalizeAngle(az - fusion.heading); // -180..180
          double xNorm = relativeAz / (fovHorizontal/2); // -1..1
          double yNorm = ( (alt - fusion.pitch) ) / (fovVertical/2); // -1..1, approximate using pitch
          double x = (xNorm * (screenW/2)) + (screenW/2);
          double y = ((-yNorm) * (screenH/2)) + (screenH/2);
          list.add(ProjectedObject(name: s['name'], position: Offset(x, y), magnitude: (s['mag'] as num).toDouble(), type: s['type'] ?? 'star'));
        }
      } catch (e) {
        continue;
      }
    }

    // Satellites: fetch a small set of TLEs and propagate via backend for accurate az/alt
    if (showSatellites) {
      try {
        // example: fetch TLEs category 'visual' and take first 3
        final lines = await tleService.fetchTle('visual');
        // TLEs are in groups of 3 lines: name, line1, line2
        for (int i=0; i<lines.length && i<9; i+=3) {
          final name = lines[i].trim();
          final l1 = lines[i+1].trim();
          final l2 = lines[i+2].trim();
          // call backend
          try {
            final resp = await http.post(Uri.parse(backendUrl), headers: {'Content-Type':'application/json'}, body: json.encode({
              'tle1': l1,
              'tle2': l2,
              'utc_iso': utc.toIso8601String() + 'Z',
              'lat': lat,
              'lon': lon
            }));
            if (resp.statusCode == 200) {
              final j = json.decode(resp.body);
              double az = (j['az'] as num).toDouble();
              double alt = (j['alt'] as num).toDouble();
              if (alt > 0) {
                double relativeAz = normalizeAngle(az - fusion.heading);
                double xNorm = relativeAz / (fovHorizontal/2);
                double yNorm = ( (alt - fusion.pitch) ) / (fovVertical/2);
                double x = (xNorm * (screenW/2)) + (screenW/2);
                double y = ((-yNorm) * (screenH/2)) + (screenH/2);
                list.add(ProjectedObject(name: name, position: Offset(x,y), magnitude: 0.0, type: 'satellite'));
              }
            }
          } catch (e) {
            // ignore backend errors, could use local sgp4 stub
            final sat = Satellite(name: name, tleLine1: l1, tleLine2: l2);
            final pos = sat.propagateFake(utc, lat, lon);
            double az = pos['az']!;
            double alt = pos['alt']!;
            if (alt > 0) {
              double relativeAz = normalizeAngle(az - fusion.heading);
              double xNorm = relativeAz / (fovHorizontal/2);
              double yNorm = ( (alt - fusion.pitch) ) / (fovVertical/2);
              double x = (xNorm * (screenW/2)) + (screenW/2);
              double y = ((-yNorm) * (screenH/2)) + (screenH/2);
              list.add(ProjectedObject(name: name, position: Offset(x,y), magnitude: 0.0, type: 'satellite'));
            }
          }
        }
      } catch (e) {
        // ignore
      }
    }

    setState(() {
      projected = list;
    });
  }

  double normalizeAngle(double a) {
    double ang = a % 360.0;
    if (ang > 180) ang -= 360;
    if (ang < -180) ang += 360;
    return ang;
  }

  @override
  void dispose() {
    controller?.dispose();
    fusion.stop();
    _compassSub?.cancel();
    _accelSub?.cancel();
    _projTimer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('AstroFinder'),
        actions: [
          IconButton(icon: Icon(Icons.star), onPressed: () { Navigator.push(context, MaterialPageRoute(builder: (_) => IapScreen())); })
        ],
      ),
      body: controller == null || !controller!.value.isInitialized
          ? Center(child: CircularProgressIndicator())
          : Stack(
              children: [
                CameraPreview(controller!),
                Positioned.fill(child: CustomPaint(painter: OverlayPainter(objects: projected))),
                Positioned(
                  bottom: 0,
                  left: 0,
                  right: 0,
                  child: Container(
                    color: Colors.black45,
                    padding: EdgeInsets.all(8),
                    child: Wrap(
                      spacing: 8,
                      children: [
                        FilterChip(label: Text('Planets'), selected: showPlanets, onSelected: (v){ setState(()=> showPlanets=v); }),
                        FilterChip(label: Text('Constellations'), selected: showConstellations, onSelected: (v){ setState(()=> showConstellations=v); }),
                        FilterChip(label: Text('Satellites'), selected: showSatellites, onSelected: (v){ setState(()=> showSatellites=v); }),
                        FilterChip(label: Text('Events'), selected: showEvents, onSelected: (v){ setState(()=> showEvents=v); }),
                      ],
                    ),
                  ),
                )
              ],
            ),
    );
  }
}
