
import 'dart:async';
import 'dart:math' as math;
import 'package:sensors_plus/sensors_plus.dart';
import 'package:flutter_compass/flutter_compass.dart';

/// Simple complementary filter for heading and pitch.
/// - Uses compass (magnetometer) as low-frequency reference (heading)
/// - Uses gyroscope for high-frequency changes (integrated)
/// - Uses accelerometer for pitch estimate
///
/// This is not a full Kalman filter, but is lightweight and improves stability.
class SensorFusion {
  double _heading = 0.0; // degrees
  double _gyroHeading = 0.0;
  double _lastGyroTimestamp = 0.0;
  double _alpha = 0.98; // complementary filter coeff: gyro weight

  StreamSubscription? _gyroSub;
  StreamSubscription? _compassSub;
  StreamSubscription? _accelSub;

  double pitch = 0.0; // degrees

  void start() {
    _compassSub = FlutterCompass.events?.listen((event) {
      if (event != null && event.heading != null) {
        double magHeading = event.heading!;
        // combine gyro integrated heading with magnetometer using complementary filter
        _heading = _alpha * _gyroHeading + (1 - _alpha) * magHeading;
      }
    });

    _gyroSub = gyroscopeEvents.listen((g) {
      // integrate z rotation (approx). gyroscope reports rad/s
      final now = DateTime.now().millisecondsSinceEpoch / 1000.0;
      if (_lastGyroTimestamp == 0.0) _lastGyroTimestamp = now;
      final dt = now - _lastGyroTimestamp;
      _lastGyroTimestamp = now;
      // gyroscope z axis is rotation around device axis; convert to degrees
      double gz = g.z;
      double degPerSec = gz * (180.0 / math.pi);
      _gyroHeading = (_gyroHeading + degPerSec * dt) % 360.0;
      _heading = _alpha * _gyroHeading + (1 - _alpha) * _heading;
    });

    _accelSub = accelerometerEvents.listen((a) {
      // pitch estimate from accelerometer
      double ax = a.x, ay = a.y, az = a.z;
      pitch = math.atan2(-ax, math.sqrt(ay * ay + az * az)) * 180.0 / math.pi;
    });
  }

  double get heading => _heading;

  void stop() {
    _gyroSub?.cancel();
    _compassSub?.cancel();
    _accelSub?.cancel();
  }
}
