import 'package:flutter/material.dart';

class ProjectedObject {
  final String name;
  final Offset position; // position on screen
  final double magnitude;
  final String type; // star, planet, satellite
  ProjectedObject({required this.name, required this.position, required this.magnitude, required this.type});
}

class OverlayPainter extends CustomPainter {
  final List<ProjectedObject> objects;
  OverlayPainter({required this.objects});

  @override
  void paint(Canvas canvas, Size size) {
    final starPaint = Paint()..color = Colors.yellow..style = PaintingStyle.fill;
    final planetPaint = Paint()..color = Colors.blue..style = PaintingStyle.fill;
    final satPaint = Paint()..color = Colors.red..style = PaintingStyle.fill;

    for (var obj in objects) {
      final pos = obj.position;
      if (pos.dx < 0 || pos.dy < 0 || pos.dx > size.width || pos.dy > size.height) continue;
      Paint p = starPaint;
      if (obj.type == 'planet') p = planetPaint;
      if (obj.type == 'satellite') p = satPaint;
      double radius = (obj.magnitude != 0) ? (6.0 - (obj.magnitude / 2.0)).clamp(2.0, 6.0) : 4.0;
      canvas.drawCircle(pos, radius, p);
      final tp = TextPainter(
        text: TextSpan(text: obj.name, style: TextStyle(color: Colors.white, fontSize: 12)),
        textDirection: TextDirection.ltr,
      );
      tp.layout();
      tp.paint(canvas, pos + Offset(8, -8));
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => true;
}
